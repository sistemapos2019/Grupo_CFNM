# Grupo_CFNM
Entregas  del sistema para la materia diseño de sistemas 2 uesfmocc-2019 

### Integrantes:
- Cuellar Rodriguez Carlos Mauricio
- Flores Quintanilla Karen Idalia
- Martinez Matamoros, William Otoniel
- Nerio Hernandez Daniel Ernesto

# Planificación de pruebas del sistema
El siguiente documento en google Drive contiene el documento del manual de pruebas: 
https://docs.google.com/document/d/1lfVeGD2VIdSPY8jZI3x1NJ4Ymiehjk9uiqhFx8WXvUw/edit?usp=sharing
Dentro de este documento realizará los detalles de las pruebas que le han sido asignadas a su grupo, al final entre todos los compañeros vamos a conformar el documento del manual de pruebas. Las pruebas de un módulo pueden incluir dos o mas pruebas especificas, por ejemplo la prueba 1-02 Modulo de Bitácoras incluye dos pruebas la 1-02-01 y la 1-02-02


##### a su grupo les son asignados las siguientes pruebas
* 1-02 Modulo de bitácora
* 2-08 Integración productos y menú
