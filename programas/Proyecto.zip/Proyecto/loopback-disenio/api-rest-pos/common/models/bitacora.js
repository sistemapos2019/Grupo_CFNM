'use strict';

module.exports = function(Bitacora) {

};
