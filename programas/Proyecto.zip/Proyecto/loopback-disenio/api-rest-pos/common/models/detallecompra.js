'use strict';

module.exports = function(Detallecompra) {

};
