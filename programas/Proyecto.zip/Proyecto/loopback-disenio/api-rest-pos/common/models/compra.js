'use strict';

module.exports = function(Compra) {

};
