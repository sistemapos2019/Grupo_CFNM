'use strict';

module.exports = function(Dashboardllevar) {

};
