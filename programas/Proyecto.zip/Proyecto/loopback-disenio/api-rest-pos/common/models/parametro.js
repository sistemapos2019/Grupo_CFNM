'use strict';

module.exports = function(Parametro) {

};
