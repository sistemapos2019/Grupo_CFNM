'use strict';

module.exports = function(Dashboardprincipal) {

};
