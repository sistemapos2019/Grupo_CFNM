# loopback-disenio
simple api rest hecha para la materia de diseño de sistemas uesfmocc
